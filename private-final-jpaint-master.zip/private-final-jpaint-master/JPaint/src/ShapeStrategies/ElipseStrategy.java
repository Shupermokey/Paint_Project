package ShapeStrategies;

import java.awt.Graphics2D;

import model.ShapeShadingType;
import model.ShapeType;
import view.gui.EnumColorMap;
import view.gui.Shape;
import view.interfaces.PaintCanvasBase;

public class ElipseStrategy implements IShapeStrategies{

	@Override
	public void shapeStrategy(Shape shape,PaintCanvasBase paintCanvasBase) {
		
		
		
	}

}
