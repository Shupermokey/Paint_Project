package view.interfaces;

public interface IShape {

	public void draw(PaintCanvasBase paintCanvasBase);
	
	public void move();
	
}
