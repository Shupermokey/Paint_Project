package view.interfaces;

public interface IDrawShapeHandler {

}
