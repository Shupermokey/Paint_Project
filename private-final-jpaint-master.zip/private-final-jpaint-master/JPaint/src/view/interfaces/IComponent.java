package view.interfaces;

public interface IComponent {
	
	void someAction();

}
