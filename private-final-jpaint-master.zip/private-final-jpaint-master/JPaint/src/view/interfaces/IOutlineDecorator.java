package view.interfaces;

public interface IOutlineDecorator {

}
