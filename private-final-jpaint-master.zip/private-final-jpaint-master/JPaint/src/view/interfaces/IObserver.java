package view.interfaces;

public interface IObserver {

	void update();
	
}
