package ShapeStrategies;

import model.ShapeType;
import view.gui.Shape;
import view.interfaces.PaintCanvasBase;

public interface IShapeStrategies {

	void shapeStrategy(Shape shape, PaintCanvasBase paintCanvasBase);
	
}
